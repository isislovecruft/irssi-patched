#ifndef __FLOOD_H
#define __FLOOD_H

void flood_init(void);
void flood_deinit(void);

#endif
